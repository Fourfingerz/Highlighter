$(document).ready(function() {
	$('#add').click(function() {
		alert("OK");
	});
});
